# Relevnt - Deployment Guide

## 🚀 Quick Deploy to Netlify

### Prerequisites
- Git repository set up
- Netlify account connected to your repo
- Supabase project created

### Step 1: Verify Your Local Structure

Your project should have this structure:

```
relevnt/
├── package.json          ✅ (just created)
├── tsconfig.json         ✅ (just created)
├── vite.config.ts        ✅ (just created)
├── index.html            ✅ (just created)
├── netlify.toml          ✅ (just created)
├── .gitignore            ✅ (just created)
├── src/
│   ├── main.tsx          ⚠️ (need to create)
│   ├── App.tsx           ⚠️ (need to create)
│   ├── pages/            ⚠️ (move your pages here)
│   ├── context/          ⚠️ (AuthContext)
│   └── api/              ⚠️ (base44Adapter)
└── netlify/
    └── functions/        ✅ (your backend code)
```

### Step 2: Organize Your Files

Run these commands in your project root:

```bash
# Create src directory structure
mkdir -p src/pages
mkdir -p src/context
mkdir -p src/api
mkdir -p src/lib

# Move your pages (if they're not already in src/pages/)
# Adjust the path if your pages are elsewhere
cp pages/*.tsx src/pages/ 2>/dev/null || echo "Pages already in place"

# Move functions to the right place
mkdir -p netlify/functions
cp -r functions/* netlify/functions/ 2>/dev/null || echo "Functions already in place"
```

### Step 3: Create Essential Files

You need to create these files (I'll provide them separately):

1. `src/main.tsx` - Entry point
2. `src/App.tsx` - Main app component with routing
3. `src/context/AuthContext.tsx` - Authentication context
4. `src/api/base44Adapter.ts` - API adapter
5. `src/lib/supabase.ts` - Supabase client

### Step 4: Set Environment Variables in Netlify

Go to Netlify Dashboard → Your Site → Site configuration → Environment variables

Add these variables:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### Step 5: Deploy

```bash
# Make sure you're in the project root
pwd

# Add all files
git add .

# Commit
git commit -m "Add deployment configuration"

# Push to trigger deploy
git push origin main
```

### Step 6: Monitor Deploy

Watch the Netlify deploy logs. It should:
1. ✅ Find package.json
2. ✅ Run `npm install`
3. ✅ Run `npm run build`
4. ✅ Publish the `dist` folder
5. ✅ Deploy functions from `netlify/functions`

## 🐛 Troubleshooting

### "Cannot find package.json"
- Make sure `package.json` is at the ROOT of your repo
- Check: `git ls-files | grep package.json`
- If missing: `git add package.json && git commit -m "Add package.json"`

### "Module not found: @/..."
- Check that `src/` directory exists
- Verify `vite.config.ts` has the path alias
- Ensure files are in the correct `src/` subdirectories

### "Build failed"
- Check that all imported files exist
- Verify all dependencies are in `package.json`
- Look for TypeScript errors in the logs

### Functions not working
- Ensure functions are in `netlify/functions/`
- Check that `netlify.toml` points to the right directory
- Verify functions export a `handler` function

## 📝 Next Steps After Successful Deploy

1. Visit your site URL
2. Test login/signup
3. Create a job
4. Verify data persists
5. Test each page

## 🎓 What You Learned

- **Project Structure**: How to organize a full-stack app
- **Build Configuration**: Vite, TypeScript, and Netlify setup
- **Deployment**: Git-based deployment workflow
- **Environment Variables**: Keeping secrets secure
- **Debugging**: Reading build logs and fixing issues
